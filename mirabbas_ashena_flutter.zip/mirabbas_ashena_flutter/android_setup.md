# Android / Gradle

این نسخه شامل پوشه Android، تنظیمات Gradle، Manifest و MainActivity است.

## Firebase
فایل `lib/firebase_options.dart` در ZIP اصلی عمداً بدون مشخصات پروژه Firebase است. برای اجرای واقعی:

```bash
firebase login
dart pub global activate flutterfire_cli
flutterfire configure
```

## ساخت APK

```bash
flutter pub get
flutter build apk --release
```

در GitHub Actions اگر `gradle-wrapper.jar` موجود نباشد، workflow با `flutter create . --platforms=android` آن را تولید می‌کند و سپس APK را می‌سازد.
