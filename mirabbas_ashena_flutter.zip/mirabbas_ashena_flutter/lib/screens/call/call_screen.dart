import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import '../../services/call_service.dart';

class CallScreen extends StatefulWidget {
  final String callId, peerName, type; final bool caller;
  const CallScreen({super.key, required this.callId, required this.peerName, required this.type, required this.caller});
  @override State<CallScreen> createState() => _CallScreenState();
}
class _CallScreenState extends State<CallScreen> {
  final local = RTCVideoRenderer(); final remote = RTCVideoRenderer(); final service = CallService();
  RTCPeerConnection? pc; MediaStream? stream; bool mic = true, camera = true;
  final config = {'iceServers': [{'urls': 'stun:stun.l.google.com:19302'}]};

  @override void initState() { super.initState(); _init(); }
  Future<void> _init() async {
    await local.initialize(); await remote.initialize();
    pc = await createPeerConnection(config);
    if (widget.type == 'video') { stream = await navigator.mediaDevices.getUserMedia({'audio': true, 'video': true}); } else { stream = await navigator.mediaDevices.getUserMedia({'audio': true, 'video': false}); }
    local.srcObject = stream;
    for (final t in stream!.getTracks()) { await pc!.addTrack(t, stream!); }
    pc!.onTrack = (e) { if (e.streams.isNotEmpty) remote.srcObject = e.streams.first; };
    pc!.onIceCandidate = (c) { if (c.candidate != null) service.addCandidate(widget.callId, widget.caller ? 'callerCandidates' : 'receiverCandidates', c); };
    if (widget.caller) {
      final offer = await pc!.createOffer(); await pc!.setLocalDescription(offer); await service.setOffer(widget.callId, offer);
      service.watchCall(widget.callId).listen((snap) async { final d = snap.data(); final a = d?['answer']; if (a != null && pc!.getRemoteDescription() == null) await pc!.setRemoteDescription(RTCSessionDescription(a['sdp'], a['type'])); });
    } else {
      service.watchCall(widget.callId).listen((snap) async { final d = snap.data(); final o = d?['offer']; if (o != null && pc!.getRemoteDescription() == null) { await pc!.setRemoteDescription(RTCSessionDescription(o['sdp'], o['type'])); final a = await pc!.createAnswer(); await pc!.setLocalDescription(a); await service.setAnswer(widget.callId, a); } });
    }
    service.candidates(widget.callId, widget.caller ? 'receiverCandidates' : 'callerCandidates').listen((s) { for (final d in s.docChanges) { final x=d.doc.data(); pc?.addCandidate(RTCIceCandidate(x['candidate'], x['sdpMid'], x['sdpMLineIndex'])); } });
    if (mounted) setState(() {});
  }

  void _mic() { mic=!mic; for(final t in stream?.getAudioTracks() ?? []) { t.enabled=mic; } setState(() {}); }
  void _camera() { camera=!camera; for(final t in stream?.getVideoTracks() ?? []) { t.enabled=camera; } setState(() {}); }
  Future<void> _end() async { await service.updateStatus(widget.callId, 'ended'); await stream?.dispose(); await pc?.close(); if(mounted) Navigator.pop(context); }
  @override void dispose(){ local.dispose(); remote.dispose(); pc?.close(); super.dispose(); }

  @override Widget build(BuildContext context) => Scaffold(backgroundColor: Colors.black, body: Stack(children: [
    Positioned.fill(child: widget.type == 'video' ? RTCVideoView(remote, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover) : const Center(child: Icon(Icons.person, color: Colors.white, size: 100))),
    Positioned(top: 50, right: 20, child: Text(widget.peerName, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold))),
    if(widget.type=='video') Positioned(right: 18, bottom: 130, width: 110, height: 160, child: ClipRRect(borderRadius: BorderRadius.circular(12), child: RTCVideoView(local, mirror: true))),
    Positioned(bottom: 35, left: 0, right: 0, child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      IconButton(onPressed: _mic, style: IconButton.styleFrom(backgroundColor: Colors.white24), icon: Icon(mic?Icons.mic:Icons.mic_off, color: Colors.white)),
      const SizedBox(width: 16), if(widget.type=='video') IconButton(onPressed: _camera, style: IconButton.styleFrom(backgroundColor: Colors.white24), icon: Icon(camera?Icons.videocam:Icons.videocam_off, color: Colors.white)),
      const SizedBox(width: 16), IconButton(onPressed: _end, style: IconButton.styleFrom(backgroundColor: Colors.red), icon: const Icon(Icons.call_end, color: Colors.white)),
    ])),
  ]));
}
