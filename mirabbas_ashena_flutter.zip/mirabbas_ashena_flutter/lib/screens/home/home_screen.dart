import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../../models/user_model.dart';
import '../../services/auth_service.dart';
import '../../services/call_service.dart';
import '../../services/user_service.dart';
import '../../widgets/user_tile.dart';
import '../call/call_screen.dart';

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState() => _HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> {
  final userService = UserService();
  final callService = CallService();
  StreamSubscription? incoming;
  final Set<String> shown = {};
  String get uid => FirebaseAuth.instance.currentUser!.uid;

  @override void initState() { super.initState(); userService.setOnline(uid, true); incoming = callService.incomingCalls(uid).listen((s) { for (final c in s.docChanges) { if (c.type == DocumentChangeType.added && shown.add(c.doc.id)) _incoming(c.doc.id, c.data()); } }); }
  @override void dispose() { incoming?.cancel(); userService.setOnline(uid, false); super.dispose(); }

  Future<void> _incoming(String id, Map<String,dynamic> d) async {
    if (!mounted) return;
    final accept = await showDialog<bool>(context: context, barrierDismissible: false, builder: (_) => AlertDialog(
      title: const Text('تماس ورودی'),
      content: Text('${d['callerName'] ?? 'کاربر'} با شما تماس می‌گیرد.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('رد')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('پاسخ'))],
    ));
    if (accept == true && mounted) { await callService.updateStatus(id, 'accepted'); _openCall(id, d['callerName'] ?? 'تماس', d['type'] ?? 'video', false); }
    else { await callService.updateStatus(id, 'rejected'); }
  }

  Future<void> _call(UserModel u, String type) async {
    final me = FirebaseAuth.instance.currentUser!;
    final callId = await callService.createCall(callerId: me.uid, receiverId: u.id, callerName: me.email ?? 'کاربر', receiverName: u.name, type: type);
    if (mounted) _openCall(callId, u.name, type, true);
  }
  void _openCall(String id, String name, String type, bool caller) => Navigator.push(context, MaterialPageRoute(builder: (_) => CallScreen(callId: id, peerName: name, type: type, caller: caller)));

  @override Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: Scaffold(
    appBar: AppBar(title: const Text('میرعباس آشنا'), actions: [IconButton(onPressed: () => AuthService().logout(), icon: const Icon(Icons.logout))]),
    body: StreamBuilder<List<UserModel>>(stream: userService.streamOtherUsers(uid), builder: (context, s) {
      if (s.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
      final users = s.data ?? [];
      if (users.isEmpty) return const Center(child: Text('هنوز کاربر دیگری ثبت‌نام نکرده است.'));
      return ListView.builder(padding: const EdgeInsets.all(12), itemCount: users.length, itemBuilder: (_, i) => UserTile(user: users[i], onVideo: () => _call(users[i], 'video'), onAudio: () => _call(users[i], 'audio')));
    }),
  ));
}
