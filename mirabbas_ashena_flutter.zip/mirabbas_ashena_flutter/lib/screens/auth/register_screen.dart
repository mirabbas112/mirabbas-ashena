import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../../services/auth_service.dart';
import '../../services/user_service.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override State<RegisterScreen> createState() => _RegisterScreenState();
}
class _RegisterScreenState extends State<RegisterScreen> {
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;

  Future<void> register() async {
    setState(() => loading = true);
    try {
      final cred = await AuthService().register(email.text, password.text);
      await UserService().createUser(uid: cred.user!.uid, name: name.text, email: email.text);
      if (mounted) Navigator.pop(context);
    } on FirebaseAuthException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'خطا در ثبت‌نام')));
    } finally { if (mounted) setState(() => loading = false); }
  }

  @override Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(appBar: AppBar(title: const Text('ثبت‌نام')), body: SingleChildScrollView(padding: const EdgeInsets.all(24), child: Column(children: [
      TextField(controller: name, decoration: const InputDecoration(labelText: 'نام', border: OutlineInputBorder())),
      const SizedBox(height: 14),
      TextField(controller: email, decoration: const InputDecoration(labelText: 'ایمیل', border: OutlineInputBorder())),
      const SizedBox(height: 14),
      TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'رمز عبور', border: OutlineInputBorder())),
      const SizedBox(height: 20),
      SizedBox(width: double.infinity, height: 52, child: FilledButton(onPressed: loading ? null : register, child: loading ? const CircularProgressIndicator() : const Text('ساخت حساب'))),
    ])),),
  );
}
