import 'package:flutter/material.dart';
import '../models/user_model.dart';

class UserTile extends StatelessWidget {
  final UserModel user;
  final VoidCallback onVideo;
  final VoidCallback onAudio;
  const UserTile({super.key, required this.user, required this.onVideo, required this.onAudio});

  @override Widget build(BuildContext context) => Card(child: ListTile(
    leading: Stack(children: [
      CircleAvatar(radius: 25, backgroundImage: user.photoUrl != null ? NetworkImage(user.photoUrl!) : const AssetImage('assets/images/profile.png') as ImageProvider),
      if (user.online) Positioned(right: 0, bottom: 0, child: Container(width: 13, height: 13, decoration: BoxDecoration(color: Colors.green, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)))),
    ]),
    title: Text(user.name),
    subtitle: Text(user.online ? 'آنلاین' : 'آفلاین'),
    trailing: Wrap(children: [IconButton(onPressed: onAudio, icon: const Icon(Icons.call)), IconButton(onPressed: onVideo, icon: const Icon(Icons.videocam))]),
  ));
}
