import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String id;
  final String name;
  final String email;
  final String? photoUrl;
  final bool online;
  final DateTime? lastSeen;

  const UserModel({
    required this.id,
    required this.name,
    required this.email,
    this.photoUrl,
    this.online = false,
    this.lastSeen,
  });

  factory UserModel.fromFirestore(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? {};
    return UserModel(
      id: doc.id,
      name: (d['name'] ?? '') as String,
      email: (d['email'] ?? '') as String,
      photoUrl: d['photoUrl'] as String?,
      online: (d['online'] ?? false) as bool,
      lastSeen: (d['lastSeen'] as Timestamp?)?.toDate(),
    );
  }
}
