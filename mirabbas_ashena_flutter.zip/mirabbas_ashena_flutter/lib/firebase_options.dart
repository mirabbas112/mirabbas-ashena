// این فایل را با اجرای `flutterfire configure` تولید کنید.
// مقادیر Firebase به‌دلیل وابستگی به پروژه شخصی شما عمداً داخل ZIP قرار داده نشده‌اند.
import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform => throw UnsupportedError(
    'Firebase تنظیم نشده است. ابتدا `flutterfire configure` را اجرا کنید.',
  );
}
