import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

class CallService {
  final _calls = FirebaseFirestore.instance.collection('calls');

  Future<String> createCall({
    required String callerId,
    required String receiverId,
    required String callerName,
    required String receiverName,
    String type = 'video',
  }) async {
    final ref = _calls.doc();
    await ref.set({
      'callerId': callerId,
      'receiverId': receiverId,
      'callerName': callerName,
      'receiverName': receiverName,
      'type': type,
      'status': 'ringing',
      'createdAt': FieldValue.serverTimestamp(),
    });
    return ref.id;
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> incomingCalls(String uid) =>
      _calls.where('receiverId', isEqualTo: uid).where('status', isEqualTo: 'ringing').snapshots();

  Stream<DocumentSnapshot<Map<String, dynamic>>> watchCall(String id) => _calls.doc(id).snapshots();

  Future<void> updateStatus(String id, String status) => _calls.doc(id).update({'status': status});

  Future<void> setOffer(String id, RTCSessionDescription offer) => _calls.doc(id).update({
        'offer': {'type': offer.type, 'sdp': offer.sdp},
      });

  Future<void> setAnswer(String id, RTCSessionDescription answer) => _calls.doc(id).update({
        'answer': {'type': answer.type, 'sdp': answer.sdp},
        'status': 'accepted',
      });

  Future<void> addCandidate(String id, String side, RTCIceCandidate c) =>
      _calls.doc(id).collection(side).add({
        'candidate': c.candidate,
        'sdpMid': c.sdpMid,
        'sdpMLineIndex': c.sdpMLineIndex,
      });

  Stream<QuerySnapshot<Map<String, dynamic>>> candidates(String id, String side) =>
      _calls.doc(id).collection(side).snapshots();
}
