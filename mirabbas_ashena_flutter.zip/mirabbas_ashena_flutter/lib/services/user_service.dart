import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';

class UserService {
  final _users = FirebaseFirestore.instance.collection('users');

  Future<void> createUser({required String uid, required String name, required String email}) async {
    await _users.doc(uid).set({
      'name': name.trim(),
      'email': email.trim(),
      'photoUrl': null,
      'online': true,
      'lastSeen': FieldValue.serverTimestamp(),
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<List<UserModel>> streamOtherUsers(String uid) =>
      _users.orderBy('name').snapshots().map((s) => s.docs
          .where((d) => d.id != uid)
          .map(UserModel.fromFirestore)
          .toList());

  Future<void> setOnline(String uid, bool online) => _users.doc(uid).update({
        'online': online,
        'lastSeen': FieldValue.serverTimestamp(),
      });
}
