# میرعباس آشنا

پروژه Flutter تماس صوتی و تصویری با Firebase + Firestore + WebRTC.

این نسخه بر اساس ZIP اصلی ساخته شده و **پوشه Android و فایل‌های Gradle لازم** را اضافه می‌کند تا پروژه ساختار استاندارد Flutter داشته باشد.

## امکانات پایه
- ثبت‌نام و ورود
- فهرست کاربران
- وضعیت آنلاین/آفلاین
- تماس صوتی و تصویری
- قبول/رد تماس
- میکروفون و دوربین
- WebRTC با signaling در Firestore
- STUN اولیه

## راه‌اندازی محلی

```bash
flutter pub get
firebase login
dart pub global activate flutterfire_cli
flutterfire configure
flutter run
```

> بدون `flutterfire configure`، برنامه اطلاعات اتصال Firebase واقعی را ندارد و اجرای Firebase کامل نخواهد بود.

## ساخت APK

```bash
flutter clean
flutter pub get
flutter build apk --release
```

خروجی:
`build/app/outputs/flutter-apk/app-release.apk`

## GitHub Actions

فایل `.github/workflows/main.yml` برای ساخت خودکار APK اضافه شده است. اگر Gradle Wrapper در مخزن موجود نباشد، workflow ابتدا با Flutter پوشه Android/Wrapper را کامل می‌کند و بعد APK می‌سازد.

## Production

برای نسخه نهایی باید TURN server، FCM، اعلان تماس ورودی، ringtone، تماس در پس‌زمینه، timeout و قوانین دقیق Firestore اضافه شوند.
