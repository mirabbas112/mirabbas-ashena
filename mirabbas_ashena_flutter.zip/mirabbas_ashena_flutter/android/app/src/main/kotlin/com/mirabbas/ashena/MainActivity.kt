package com.mirabbas.ashena

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
