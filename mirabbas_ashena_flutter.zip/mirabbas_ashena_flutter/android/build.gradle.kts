// Root Gradle file for the Flutter Android host.
// Plugin versions are declared in settings.gradle.kts.
