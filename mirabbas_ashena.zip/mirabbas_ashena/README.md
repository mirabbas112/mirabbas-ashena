# میرعباس آشنا

اپلیکیشن Flutter برای ثبت‌نام، فهرست کاربران و تماس صوتی/تصویری با Firebase + Firestore + WebRTC.

## نکته مهم
این پروژه سورس اولیه و قابل توسعه است. برای ساخت APK واقعی باید روی یک سیستم دارای Flutter/Android SDK اجرا شود و Firebase پروژه واقعی شما متصل شود.

## راه‌اندازی

```bash
flutter create . --org com.mirabbas --project-name mirabbas_ashena
flutter pub get
firebase login
dart pub global activate flutterfire_cli
flutterfire configure
flutter run
```

در Firebase:
- Authentication > Email/Password را فعال کنید.
- Firestore Database را ایجاد کنید.
- قوانین Firestore را از فایل `firestore.rules` اعمال کنید.

## ساخت APK

```bash
flutter clean
flutter pub get
flutter build apk --release
```

خروجی معمولاً در مسیر زیر قرار می‌گیرد:
`build/app/outputs/flutter-apk/app-release.apk`

## قابلیت‌های نسخه پایه
- ثبت‌نام و ورود
- پروفایل اولیه
- نمایش کاربران آنلاین/آفلاین
- تماس صوتی
- تماس تصویری
- قبول/رد تماس
- میکروفون و دوربین
- WebRTC signaling با Firestore
- STUN اولیه

## برای نسخه Production
TURN server، FCM برای تماس هنگام پس‌زمینه/بسته بودن برنامه، اعلان تماس، ringtone، امنیت دقیق Firestore، timeout تماس و مدیریت بهتر ICE باید اضافه شوند.
