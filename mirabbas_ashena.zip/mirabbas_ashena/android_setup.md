# تنظیم Android

این مخزن کد Flutter را نگه می‌دارد. چون محیط ساخت Flutter در این سیستم نصب نیست، پوشه‌های platform به‌صورت کامل تولید نشده‌اند.

روی سیستم دارای Flutter اجرا کنید:

```bash
flutter create . --org com.mirabbas --project-name mirabbas_ashena
flutter pub get
```

سپس AndroidManifest را برای دوربین/میکروفن تنظیم کنید و Firebase را با FlutterFire متصل کنید.
